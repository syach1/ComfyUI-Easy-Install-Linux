#!/bin/bash

# Title: TeaCache Fix for 'ComfyUI Easy Install' by ivo
# Pixaroma Community Edition
# Fixes the precompute_freqs_cis import issue in TeaCache nodes.py

cd "$(dirname "$0")"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
RESET='\033[0m'

echo -e "${GREEN}::::::::::::::: TeaCache Fix :::::::::::::::${RESET}"
echo ""

# Find TeaCache nodes.py
TEACACHE_DIR="../../ComfyUI/custom_nodes/teacache"
NODES_FILE="$TEACACHE_DIR/nodes.py"

if [ ! -f "$NODES_FILE" ]; then
    echo -e "${RED}✗ TeaCache nodes.py not found at: $NODES_FILE${RESET}"
    echo -e "${YELLOW}Make sure TeaCache is installed in custom_nodes/teacache${RESET}"
    exit 1
fi

echo -e "${GREEN}✓${RESET} Found TeaCache nodes.py"

# Create backup
BACKUP_FILE="$NODES_FILE.backup"
if [ ! -f "$BACKUP_FILE" ]; then
    cp "$NODES_FILE" "$BACKUP_FILE"
    echo -e "${GREEN}✓${RESET} Created backup: nodes.py.backup"
else
    echo -e "${YELLOW}✓${RESET} Backup already exists"
fi

# Check if fix is already applied
if grep -q "from comfy.ldm.lightricks.model import LTXBaseModel" "$NODES_FILE"; then
    echo -e "${YELLOW}✓${RESET} Fix already applied - nodes.py is up to date"
    echo ""
    echo -e "${GREEN}::::::::::::::: No changes needed :::::::::::::::${RESET}"
    exit 0
fi

# Apply fix 1: Replace import statement
echo -e "${CYAN}Applying fix 1: Updating import statement...${RESET}"
if grep -q "from comfy.ldm.lightricks.model import precompute_freqs_cis" "$NODES_FILE"; then
    sed -i.tmp 's/from comfy\.ldm\.lightricks\.model import precompute_freqs_cis/from comfy.ldm.lightricks.model import LTXBaseModel/' "$NODES_FILE"
    rm -f "$NODES_FILE.tmp"
    echo -e "${GREEN}✓${RESET} Import statement updated"
else
    echo -e "${YELLOW}!${RESET} Import statement not found (may already be fixed or different version)"
fi

# Apply fix 2: Replace function call
echo -e "${CYAN}Applying fix 2: Updating function call...${RESET}"
if grep -q "pe = precompute_freqs_cis(" "$NODES_FILE"; then
    sed -i.tmp 's/pe = precompute_freqs_cis(/pe = LTXBaseModel.precompute_freqs_cis(/' "$NODES_FILE"
    rm -f "$NODES_FILE.tmp"
    echo -e "${GREEN}✓${RESET} Function call updated"
else
    echo -e "${YELLOW}!${RESET} Function call not found (may already be fixed or different version)"
fi

# Verify fix
echo ""
echo -e "${CYAN}Verifying fix...${RESET}"
if grep -q "from comfy.ldm.lightricks.model import LTXBaseModel" "$NODES_FILE" && \
   grep -q "pe = LTXBaseModel.precompute_freqs_cis(" "$NODES_FILE"; then
    echo -e "${GREEN}✓${RESET} Fix verified successfully!"
    echo ""
    echo -e "${GREEN}::::::::::::::: TeaCache Fix Complete :::::::::::::::${RESET}"
    echo -e "${YELLOW}Please restart ComfyUI for changes to take effect.${RESET}"
else
    echo -e "${RED}✗${RESET} Fix verification failed"
    echo -e "${YELLOW}You may need to manually edit nodes.py${RESET}"
    echo ""
    echo -e "Required changes:"
    echo -e "  Line 12: from comfy.ldm.lightricks.model import LTXBaseModel"
    echo -e "  Line 631: pe = LTXBaseModel.precompute_freqs_cis(...)"
fi
