#!/bin/bash

set -euo pipefail
cd "$(dirname "$0")"

GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
RESET='\033[0m'

PYTHON_PATH=""
if [ -f "../python_embeded/python" ]; then
    PYTHON_PATH="../python_embeded/python"
elif [ -f "../python_embeded/bin/python3" ]; then
    PYTHON_PATH="../python_embeded/bin/python3"
elif [ -f "../python_embeded/bin/python" ]; then
    PYTHON_PATH="../python_embeded/bin/python"
fi

if [ -z "$PYTHON_PATH" ]; then
    echo -e "${RED}ERROR: Embedded Python not found${RESET}"
    exit 1
fi

PY_MINOR=$("$PYTHON_PATH" -c "import sys; print(sys.version_info.minor)")
TORCH_VERSION=$("$PYTHON_PATH" -c "import torch; print(torch.__version__.split('+')[0])" | cut -d'.' -f1,2)

if [ "$PY_MINOR" = "12" ]; then
    CP_TAG="cp312"
elif [ "$PY_MINOR" = "11" ]; then
    CP_TAG="cp311"
else
    echo -e "${RED}ERROR: Unsupported Python 3.$PY_MINOR${RESET}"
    exit 1
fi

case "$TORCH_VERSION" in
    "2.7")
        WHEEL_SET="Torch270"
        ;;
    "2.8")
        WHEEL_SET="Torch280"
        ;;
    "2.9")
        WHEEL_SET="Torch291"
        ;;
    *)
        echo -e "${RED}ERROR: Unsupported Torch version $TORCH_VERSION${RESET}"
        exit 1
        ;;
esac

WHEELS_DIR="../ComfyUI/custom_nodes/ComfyUI-Trellis2/wheels/Linux/$WHEEL_SET"

echo -e "${GREEN}::::::::::::::: Installing Trellis2 Wheels${RESET}"
echo -e "${GREEN}Python: ${YELLOW}$PYTHON_PATH${RESET}"
echo -e "${GREEN}Wheel Set: ${YELLOW}$WHEEL_SET${RESET}"
echo

for wheel_name in \
    "nvdiffrast-0.4.0-${CP_TAG}-${CP_TAG}-linux_x86_64.whl" \
    "cumesh-1.0-${CP_TAG}-${CP_TAG}-linux_x86_64.whl" \
    "flex_gemm-0.0.1-${CP_TAG}-${CP_TAG}-linux_x86_64.whl" \
    "o_voxel-0.0.1-${CP_TAG}-${CP_TAG}-linux_x86_64.whl"
do
    if [ ! -f "$WHEELS_DIR/$wheel_name" ]; then
        echo -e "${RED}ERROR: Missing wheel ${wheel_name}${RESET}"
        exit 1
    fi
    echo -e "${GREEN}Installing ${YELLOW}$wheel_name${RESET}"
    "$PYTHON_PATH" -m pip install "$WHEELS_DIR/$wheel_name" --force-reinstall --no-deps
done

if ! "$PYTHON_PATH" -c "import o_voxel" >/dev/null 2>&1; then
    echo -e "${YELLOW}Bundled o_voxel wheel failed to import. Rebuilding from source...${RESET}"
    "$(dirname "$0")/Trellis2-Build-OVoxel.sh" --non-interactive
fi

echo
echo -e "${GREEN}::::::::::::::: Verifying Installation${RESET}"
for package in nvdiffrast.torch cumesh flex_gemm o_voxel; do
    if "$PYTHON_PATH" -c "import importlib; importlib.import_module('${package}'); print('✓ ${package} imported successfully')" 2>/dev/null; then
        echo -e "${GREEN}✓ ${package} is working${RESET}"
    else
        echo -e "${RED}✗ ${package} failed${RESET}"
        exit 1
    fi
done

echo
echo -e "${GREEN}::::::::::::::: Installation Complete${RESET}"
echo -e "${YELLOW}Trellis2 dependencies are ready for use!${RESET}"
