#!/bin/bash

node_name="FlashAttention"
echo "Title: '$node_name' for 'ComfyUI Easy Install' by ivo"
echo ":: Pixaroma Community Edition ::"
echo ""

# Set colors
set_colors() {
    warning='\033[33m'
    red='\033[91m'
    green='\033[92m'
    yellow='\033[93m'
    bold='\033[1m'
    reset='\033[0m'
}

set_colors

# Set arguments
PIPargs="--no-cache-dir --no-warn-script-location --timeout=1000 --retries 200 --use-pep517"
FLASH_ATTN_URL="https://github.com/mjun0812/flash-attention-prebuild-wheels/releases/download/v0.5.4/flash_attn-2.8.3%2Bcu128torch2.7-cp312-cp312-linux_x86_64.whl"

# Check Add-ons folder and locate embedded Python
PYTHON_PATH=""
if [ -f "../python_embeded/python" ]; then
    PYTHON_PATH="../python_embeded/python"
elif [ -f "../python_embeded/bin/python3" ]; then
    PYTHON_PATH="../python_embeded/bin/python3"
elif [ -f "../python_embeded/bin/python" ]; then
    PYTHON_PATH="../python_embeded/bin/python"
fi

if [ -z "$PYTHON_PATH" ]; then
    echo -e "${red}ERROR: Embedded Python not found!${reset}"
    echo -e "${green}::::::::::::::: Run this file from the ${red}'ComfyUI-Easy-Install/Add-ons'${green} folder${reset}"
    echo -e "${green}::::::::::::::: Press any key to exit...${reset}"
    read -n 1
    exit 1
fi

echo -e "${green}::::::::::::::: Using Python: ${yellow}$PYTHON_PATH${reset}"

# Clear Pip Cache - DISABLED to avoid slow connection issues
# if [ -d "$HOME/.cache/pip" ]; then
#     rm -rf "$HOME/.cache/pip" && mkdir -p "$HOME/.cache/pip"
# fi
# echo -e "${green}::::::::::::::: Clearing Pip Cache ${yellow}Done${green}${reset}"
# echo ""

get_versions() {
    echo -e "${green}::::::::::::::: Checking ${yellow}Python, Torch, CUDA ${green}versions${reset}"
    echo ""

    # Python version
    PYTHON_VERSION=$($PYTHON_PATH --version 2>&1 | awk '{print $2}' | cut -d. -f1-2)

    # Torch version
    TORCH_VERSION=$($PYTHON_PATH -c "import torch; print(torch.__version__)" | cut -d. -f1-2)

    # CUDA version
    CUDA_VERSION=$($PYTHON_PATH -c "import torch; print(torch.version.cuda if torch.cuda.is_available() else 'Not available')" | cut -d. -f1-2)

    echo -e "${green}::::::::::::::: Python Version:${yellow} $PYTHON_VERSION${reset}"
    echo -e "${green}::::::::::::::: Torch Version:${yellow} $TORCH_VERSION${reset}"
    echo -e "${green}::::::::::::::: CUDA Version:${yellow} $CUDA_VERSION${reset}"
    echo ""

    WARNINGS=0

    if [ "$PYTHON_VERSION" != "3.11" ] && [ "$PYTHON_VERSION" != "3.12" ]; then
        echo -e "${warning}WARNING: ${red}Python $PYTHON_VERSION is not supported. ${green}Supported versions: 3.11, 3.12${reset}"
        WARNINGS=1
    fi
    if [ "$TORCH_VERSION" != "2.7" ] && [ "$TORCH_VERSION" != "2.8" ] && [ "$TORCH_VERSION" != "2.9" ]; then
        echo -e "${warning}WARNING: ${red}Torch $TORCH_VERSION is not supported. ${green}Supported versions: 2.7, 2.8, 2.9${reset}"
        WARNINGS=1
    fi
    if [ "$CUDA_VERSION" != "12.8" ] && [ "$CUDA_VERSION" != "13.0" ]; then
        echo -e "${warning}WARNING: ${red}CUDA $CUDA_VERSION is not supported. ${green}Supported version: 12.8, 13.0${reset}"
        WARNINGS=1
    fi
    if [ $WARNINGS -eq 0 ]; then
        echo -e "${green}::::::::::::::: ${reset}${bold}All versions are supported! ${reset}"
        echo ""
    else
        echo ""
        echo -e "${red}::::::::::::::: Press any key to exit${reset}"
        read -n 1
        exit 1
    fi
}

get_versions

# Erasing ~* folders
find "../python_embeded/lib/python"*"/site-packages" -name '~*' -type d -exec rm -rf {} + 2>/dev/null || true

# Installing Triton
echo -e "${green}::::::::::::::: Installing${yellow} Triton${reset}"
echo ""

if [ "$TORCH_VERSION" == "2.9" ]; then
    $PYTHON_PATH -I -m pip install --upgrade --force-reinstall "triton<3.6" $PIPargs
elif [ "$TORCH_VERSION" == "2.8" ]; then
    $PYTHON_PATH -I -m pip install --upgrade --force-reinstall triton==3.1.0 $PIPargs
elif [ "$TORCH_VERSION" == "2.7" ]; then
    $PYTHON_PATH -I -m pip install --upgrade --force-reinstall triton==3.3.0 $PIPargs
fi

echo ""
echo ""

# Installing FlashAttention
echo -e "${green}::::::::::::::: Installing${yellow} $node_name${reset}"
echo ""

if [ "$TORCH_VERSION" == "2.7" ] && [ "$PYTHON_VERSION" == "3.12" ] && [ "$CUDA_VERSION" == "12.8" ]; then
    $PYTHON_PATH -I -m pip uninstall flash-attn -y --root-user-action=ignore >/dev/null 2>&1 || true
    $PYTHON_PATH -I -m pip install --force-reinstall --no-deps "$FLASH_ATTN_URL" $PIPargs
else
    # Fallback for combinations outside the tested Linux Trellis2 stack.
    $PYTHON_PATH -I -m pip install --no-build-isolation flash-attn $PIPargs
fi

$PYTHON_PATH - <<'PY'
import flash_attn

fn = getattr(flash_attn, "flash_attn_func", None)
if not callable(fn):
    raise SystemExit(f"flash_attn_func is not callable: {fn!r}")
print("flash_attn import OK")
print("flash_attn_func OK")
PY

# Creating run_nvidia_gpu_FlashAttention.sh file
echo ""
echo -e "${green}::::::::::::::: Creating${yellow} Start ComfyUI FlashAttention.sh${reset}"
echo ""

cat > "../FlashAttention.sh" << 'EOF'
#!/bin/bash

cd "$(dirname "$0")"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
MAGENTA='\033[0;35m'
CYAN='\033[0;36m'
WHITE='\033[1;37m'
BOLD='\033[1m'
RESET='\033[0m'

# Animation functions
spinner() {
    local pid=$1
    local delay=0.1
    local spinstr='⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏'
    while [ "$(ps a | awk '{print $1}' | grep $pid)" ]; do
        local temp=${spinstr#?}
        printf " ${CYAN}[%c]${RESET}  " "$spinstr"
        local spinstr=$temp${spinstr%"$temp"}
        sleep $delay
        printf "\b\b\b\b\b\b"
    done
    printf "    \b\b\b\b"
}

print_header() {
    clear
    echo -e "${MAGENTA}╔═══════════════════════════════════════════════════════════╗${RESET}"
    echo -e "${MAGENTA}║${CYAN}                                                           ${MAGENTA}║${RESET}"
    echo -e "${MAGENTA}║${CYAN}        ╔═╗╔═╗╔╦╗╔═╗╦ ╦╦ ╦╦  ${YELLOW}╔═╗╔═╗╔═╗╦ ╦              ${MAGENTA}║${RESET}"
    echo -e "${MAGENTA}║${CYAN}        ║  ║ ║║║║╠╣ ╚╦╝║ ║║  ${YELLOW}║╣ ╠═╣╚═╗╚╦╝              ${MAGENTA}║${RESET}"
    echo -e "${MAGENTA}║${CYAN}        ╚═╝╚═╝╩ ╩╚   ╩ ╚═╝╩  ${YELLOW}╚═╝╩ ╩╚═╝ ╩               ${MAGENTA}║${RESET}"
    echo -e "${MAGENTA}║${CYAN}                                                           ${MAGENTA}║${RESET}"
    echo -e "${MAGENTA}║${GREEN}              🎨 Easy Install by VenimK 🚀                ${MAGENTA}║${RESET}"
    echo -e "${MAGENTA}║${CYAN}                                                           ${MAGENTA}║${RESET}"
    echo -e "${MAGENTA}║${CYAN}               🎨 Pixaroma Soldier 🚀                       ${MAGENTA}║${RESET}"
    echo -e "${MAGENTA}║${CYAN}                                                           ${MAGENTA}║${RESET}"
    echo -e "${MAGENTA}║${YELLOW}              ⚡ FlashAttention Enabled ⚡                ${MAGENTA}║${RESET}"
    echo -e "${MAGENTA}╚═══════════════════════════════════════════════════════════╝${RESET}"
    echo ""
}

loading_bar() {
    local duration=$1
    local message=$2
    local width=50
    echo -ne "${YELLOW}${message}${RESET}\n"
    for ((i = 0 ; i <= width ; i++)); do
        echo -ne "${GREEN}▓${RESET}"
        sleep $(echo "scale=4; $duration/$width" | bc)
    done
    echo -e " ${GREEN}✓${RESET}"
}

generate_ascii_art() {
    local delay=0.05
    echo -e "${CYAN}🎨 Initializing AI Image Generator...${RESET}"
    sleep 0.5
    echo ""
    
    # Frame 1 - Empty canvas
    echo -e "${YELLOW}[Generating...]${RESET} Step 1/4 - Preparing canvas"
    echo -e "${MAGENTA}┌────────────────────┐${RESET}"
    for i in {1..6}; do
        echo -e "${MAGENTA}│${RESET}                    ${MAGENTA}│${RESET}"
        sleep $delay
    done
    echo -e "${MAGENTA}└────────────────────┘${RESET}"
    sleep 0.3
    
    # Clear and redraw with noise
    clear
    print_header
    echo -e "${YELLOW}[Generating...]${RESET} Step 2/4 - Adding noise"
    echo -e "${MAGENTA}┌────────────────────┐${RESET}"
    local chars=".:░▒▓"
    for i in {1..6}; do
        echo -ne "${MAGENTA}│${RESET}"
        for j in {1..20}; do
            local rand_char=${chars:$((RANDOM % ${#chars})):1}
            echo -ne "${CYAN}${rand_char}${RESET}"
            sleep 0.002
        done
        echo -e "${MAGENTA}│${RESET}"
    done
    echo -e "${MAGENTA}└────────────────────┘${RESET}"
    sleep 0.3
    
    # Clear and redraw with pattern forming
    clear
    print_header
    echo -e "${YELLOW}[Generating...]${RESET} Step 3/4 - Forming patterns"
    echo -e "${MAGENTA}┌────────────────────┐${RESET}"
    echo -e "${MAGENTA}│${RESET}${GREEN}░░░▒▒▓▓██${YELLOW}☼☼${GREEN}██▓▓▒▒░░░${RESET}${MAGENTA}│${RESET}"
    sleep $delay
    echo -e "${MAGENTA}│${RESET}${GREEN}░░▒▒▓▓${CYAN}████${YELLOW}◉◉${CYAN}████${GREEN}▓▓▒▒░░${RESET}${MAGENTA}│${RESET}"
    sleep $delay
    echo -e "${MAGENTA}│${RESET}${GREEN}░▒▓${CYAN}██${BLUE}▓▓▓▓${YELLOW}││${BLUE}▓▓▓▓${CYAN}██${GREEN}▓▒░${RESET}${MAGENTA}│${RESET}"
    sleep $delay
    echo -e "${MAGENTA}│${RESET}${GREEN}░▒▓${CYAN}██${BLUE}▓${WHITE}◆◆◆◆${BLUE}▓${CYAN}██${GREEN}▓▒░${RESET}${MAGENTA}│${RESET}"
    sleep $delay
    echo -e "${MAGENTA}│${RESET}${GREEN}░░▒▓${CYAN}███${BLUE}▓▓▓▓${CYAN}███${GREEN}▓▒░░${RESET}${MAGENTA}│${RESET}"
    sleep $delay
    echo -e "${MAGENTA}│${RESET}${GREEN}░░░▒▓▓${CYAN}██████${GREEN}▓▓▒░░░${RESET}${MAGENTA}│${RESET}"
    echo -e "${MAGENTA}└────────────────────┘${RESET}"
    sleep 0.3
    
    # Clear and show final image
    clear
    print_header
    echo -e "${GREEN}[Complete!]${RESET} Step 4/4 - Rendering final image ✓"
    echo -e "${MAGENTA}┌────────────────────┐${RESET}"
    echo -e "${MAGENTA}│${RESET}${GREEN}░░░▒▒▓▓██${YELLOW}☼☼${GREEN}██▓▓▒▒░░░${RESET}${MAGENTA}│${RESET}"
    echo -e "${MAGENTA}│${RESET}${GREEN}░░▒▒▓▓${CYAN}████${YELLOW}◉◉${CYAN}████${GREEN}▓▓▒▒░░${RESET}${MAGENTA}│${RESET}"
    echo -e "${MAGENTA}│${RESET}${GREEN}░▒▓${CYAN}██${BLUE}▓▓▓▓${YELLOW}││${BLUE}▓▓▓▓${CYAN}██${GREEN}▓▒░${RESET}${MAGENTA}│${RESET}"
    echo -e "${MAGENTA}│${RESET}${GREEN}░▒▓${CYAN}██${BLUE}▓${WHITE}◆◆◆◆${BLUE}▓${CYAN}██${GREEN}▓▒░${RESET}${MAGENTA}│${RESET}"
    echo -e "${MAGENTA}│${RESET}${GREEN}░░▒▓${CYAN}███${BLUE}▓▓▓▓${CYAN}███${GREEN}▓▒░░${RESET}${MAGENTA}│${RESET}"
    echo -e "${MAGENTA}│${RESET}${GREEN}░░░▒▓▓${CYAN}██████${GREEN}▓▓▒░░░${RESET}${MAGENTA}│${RESET}"
    echo -e "${MAGENTA}└────────────────────┘${RESET}"
    echo ""
    
    # Stats display
    echo -e "${CYAN}╭─────────────────────────────────────╮${RESET}"
    echo -e "${CYAN}│${RESET} ${YELLOW}⚡${RESET} Seed: ${WHITE}42424242${RESET}                  ${CYAN}│${RESET}"
    echo -e "${CYAN}│${RESET} ${GREEN}✓${RESET} Steps: ${WHITE}20${RESET}                        ${CYAN}│${RESET}"
    echo -e "${CYAN}│${RESET} ${MAGENTA}🎨${RESET} Sampler: ${WHITE}DPM++ 2M Karras${RESET}      ${CYAN}│${RESET}"
    echo -e "${CYAN}│${RESET} ${BLUE}⏱${RESET}  Time: ${WHITE}0.${RANDOM:0:2}s${RESET}                   ${CYAN}│${RESET}"
    echo -e "${CYAN}╰─────────────────────────────────────╯${RESET}"
    echo ""
    sleep 1
}

print_header

# Detect embedded Python
echo -e "${CYAN}🔍 Detecting Python environment...${RESET}"
PYTHON_CMD=""

if [ -f "python_embeded/python" ]; then
    PYTHON_CMD="./python_embeded/python"
    echo -e "${GREEN}   ✓ Found Python (embedded)${RESET}"
elif [ -f "python_embeded/bin/python3" ]; then
    PYTHON_CMD="./python_embeded/bin/python3"
    echo -e "${GREEN}   ✓ Found Python 3 (embedded)${RESET}"
elif [ -f "python_embeded/bin/python" ]; then
    PYTHON_CMD="./python_embeded/bin/python"
    echo -e "${GREEN}   ✓ Found Python (embedded)${RESET}"
fi

if [ -z "$PYTHON_CMD" ]; then
    echo -e "${RED}   ✗ Embedded Python not found!${RESET}"
    echo -e "${YELLOW}Expected: python_embeded/python${RESET}"
    exit 1
fi

echo -e "${CYAN}🐍 Using: ${YELLOW}${PYTHON_CMD}${RESET}"
echo ""

# Show ASCII art generation animation
generate_ascii_art

# Ask for custom output directory
CONFIG_FILE=".output_dir_config"
custom_output_dir=""

# Check if config file exists
if [ -f "$CONFIG_FILE" ]; then
    custom_output_dir=$(cat "$CONFIG_FILE")
    clear
    print_header
    echo -e "${CYAN}📁 Output Directory Configuration${RESET}"
    echo -e "${MAGENTA}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
    echo ""
    if [ -n "$custom_output_dir" ]; then
        echo -e "${GREEN}   ✓ Saved output directory: ${YELLOW}${custom_output_dir}${RESET}"
    else
        echo -e "${GREEN}   ✓ Using default output directory${RESET}"
    fi
    echo ""
    echo -e "${CYAN}Press Enter to continue, or type 'c' to change:${RESET}"
    read -p "> " change_choice
    
    if [ "$change_choice" = "c" ] || [ "$change_choice" = "C" ]; then
        clear
        print_header
        echo -e "${CYAN}📁 Output Directory Configuration${RESET}"
        echo -e "${MAGENTA}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
        echo ""
        echo -e "${YELLOW}Enter new output directory path:${RESET}"
        echo -e "${CYAN}Press Enter to use default, or type path:${RESET}"
        read -p "Path: " custom_output_dir
        echo "$custom_output_dir" > "$CONFIG_FILE"
        echo ""
    fi
else
    # First time setup
    clear
    print_header
    echo -e "${CYAN}📁 Output Directory Configuration${RESET}"
    echo -e "${MAGENTA}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
    echo ""
    echo -e "${YELLOW}Do you want to use a custom output directory?${RESET}"
    echo -e "${CYAN}Press Enter to use default, or type path:${RESET}"
    read -p "Path: " custom_output_dir
    echo "$custom_output_dir" > "$CONFIG_FILE"
    echo ""
fi

# Launch ComfyUI
clear
print_header
echo -e "${CYAN}🚀 Launching ComfyUI with FlashAttention...${RESET}"
echo -e "${MAGENTA}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
echo ""

export PYTHONPATH=$PWD/ComfyUI:$PYTHONPATH

# Set LD_LIBRARY_PATH to use PyTorch's bundled CUDA libraries
# This fixes "failed to open libnvrtc-builtins.so" errors
TORCH_LIB_PATH=$("$PYTHON_CMD" -c "import torch; import os; print(os.path.join(os.path.dirname(torch.__file__), 'lib'))" 2>/dev/null)
if [ -n "$TORCH_LIB_PATH" ] && [ -d "$TORCH_LIB_PATH" ]; then
    export LD_LIBRARY_PATH="$TORCH_LIB_PATH:$LD_LIBRARY_PATH"
    echo -e "${GREEN}   ✓ CUDA libraries: ${YELLOW}PyTorch bundled${RESET}"
fi

# Build command with optional output directory
if [ -n "$custom_output_dir" ]; then
    echo -e "${GREEN}   ✓ Using custom output: ${YELLOW}${custom_output_dir}${RESET}"
    echo -e "${GREEN}   ✓ FlashAttention: ${YELLOW}Enabled${RESET}"
    echo ""
    sleep 0.5
    "$PYTHON_CMD" -W ignore::FutureWarning ComfyUI/main.py --use-flash-attention --output-directory "$custom_output_dir" --listen 0.0.0.0
else
    echo -e "${GREEN}   ✓ Using default output directory${RESET}"
    echo -e "${GREEN}   ✓ FlashAttention: ${YELLOW}Enabled${RESET}"
    echo ""
    sleep 0.5
    "$PYTHON_CMD" -W ignore::FutureWarning ComfyUI/main.py --use-flash-attention --listen 0.0.0.0
fi

echo ""
echo -e "${MAGENTA}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
echo -e "${YELLOW}✨ ComfyUI session ended ✨${RESET}"
echo ""
echo -e "${GREEN}Press any key to exit...${RESET}"
read -n 1 -s
EOF

chmod +x "../FlashAttention.sh"

echo ""


# Final Messages
echo ""
echo -e "${green}:::::::::::::::${yellow} $node_name ${green}Installation Complete${reset}"
echo ""

if [ -z "$1" ]; then
    echo -e "${green}::::::::::::::: ${yellow}Press any key to exit${reset}"
    read -n 1
    exit 0
fi
