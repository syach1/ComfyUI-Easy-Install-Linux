#!/bin/bash
cd "$(dirname "$0")"

node_name="Trellis2-Build-From-Source"
echo -e "\033]0;'$node_name' for 'ComfyUI Easy Install' v0.2.0' by ivo\007"

# Pixaroma Community Edition

# Set colors
warning='\033[33m'
red='\033[91m'
green='\033[92m'
yellow='\033[93m'
bold='\033[1m'
reset='\033[0m'

# Set arguments
PIPargs="--no-cache-dir --no-warn-script-location --timeout=1000 --retries 200 --use-pep517"

# Check Add-ons folder and locate embedded Python
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PYTHON_PATH=""
if [ -f "$SCRIPT_DIR/../python_embeded/python" ]; then
    PYTHON_PATH="$SCRIPT_DIR/../python_embeded/python"
elif [ -f "$SCRIPT_DIR/../python_embeded/bin/python3" ]; then
    PYTHON_PATH="$SCRIPT_DIR/../python_embeded/bin/python3"
elif [ -f "$SCRIPT_DIR/../python_embeded/bin/python" ]; then
    PYTHON_PATH="$SCRIPT_DIR/../python_embeded/bin/python"
fi

if [ -z "$PYTHON_PATH" ]; then
    echo -e "${red}ERROR: Embedded Python not found!${reset}"
    echo -e "${green}::::::::::::::: Script location: ${yellow}$SCRIPT_DIR${reset}"
    echo -e "${green}::::::::::::::: Looking for Python in: ${yellow}$SCRIPT_DIR/../python_embeded${reset}"
    echo -e "${green}::::::::::::::: Press any key to exit...${reset}"
    read -n 1 -s
    exit 1
fi

# Clear Pip Cache - DISABLED to avoid slow connection issues
# echo -e "${green}::::::::::::::: Clearing Pip Cache ${yellow}Done${green}${reset}"
# echo

# Check system requirements
echo -e "${green}::::::::::::::: Checking System Requirements${reset}"
echo

# Check for CUDA toolkit
CUDA_HOME=""
CUDA_VERSION=""

# Check common CUDA locations
for cuda_path in "/usr/local/cuda" "/opt/cuda" "/usr/cuda"; do
    if [ -d "$cuda_path" ]; then
        CUDA_HOME="$cuda_path"
        CUDA_VERSION=$("$cuda_path/bin/nvcc" --version 2>/dev/null | grep "release" | awk '{print $6}' | cut -d',' -f1)
        break
    fi
done

if [ -z "$CUDA_HOME" ]; then
    echo -e "${red}ERROR: CUDA toolkit not found!${reset}"
    echo -e "${yellow}Please install CUDA development toolkit:${reset}"
    echo -e "${yellow}  sudo apt install nvidia-cuda-toolkit${reset}"
    echo -e "${yellow}  Or download from NVIDIA website${reset}"
    echo -e "${red}::::::::::::::: Press any key to exit${reset}"
    read -n 1 -s
    exit 1
fi

echo -e "${green}✓ CUDA Home: ${yellow}$CUDA_HOME${reset}"
echo -e "${green}✓ CUDA Version: ${yellow}$CUDA_VERSION${reset}"

# Check for build tools
if ! command -v gcc &> /dev/null; then
    echo -e "${red}ERROR: gcc not found!${reset}"
    echo -e "${yellow}Please install build tools:${reset}"
    echo -e "${yellow}  sudo apt install build-essential${reset}"
    exit 1
fi

if ! command -v git &> /dev/null; then
    echo -e "${red}ERROR: git not found!${reset}"
    echo -e "${yellow}Please install git:${reset}"
    echo -e "${yellow}  sudo apt install git${reset}"
    exit 1
fi

echo -e "${green}✓ Build tools found${reset}"

# Get Python and Torch versions
PYTHON_VERSION=$("$PYTHON_PATH" --version 2>&1 | cut -d' ' -f2 | cut -d'.' -f1,2)
TORCH_VERSION=$("$PYTHON_PATH" -c "import torch; print(torch.__version__)" 2>/dev/null | cut -d'.' -f1,2)
CUDA_TORCH_VERSION=$("$PYTHON_PATH" -c "import torch; print(torch.version.cuda if torch.cuda.is_available() else 'Not available')" 2>/dev/null | cut -d'.' -f1,2)

echo -e "${green}✓ Python Version: ${yellow}$PYTHON_VERSION${reset}"
echo -e "${green}✓ Torch Version: ${yellow}$TORCH_VERSION${reset}"
echo -e "${green}✓ CUDA Torch Version: ${yellow}$CUDA_TORCH_VERSION${reset}"

# Detect GPU and set optimal CUDA architecture
echo -e "${green}::::::::::::::: Detecting GPU${reset}"
if "$PYTHON_PATH" -c "import torch; print(torch.cuda.get_device_name(0) if torch.cuda.is_available() else 'No GPU')" 2>/dev/null; then
    GPU_NAME=$("$PYTHON_PATH" -c "import torch; print(torch.cuda.get_device_name(0))" 2>/dev/null)
    GPU_ARCH=$("$PYTHON_PATH" -c "import torch; print(torch.cuda.get_device_capability(0)[0]*10 + torch.cuda.get_device_capability(0)[1])" 2>/dev/null)
    
    echo -e "${green}✓ GPU Detected: ${yellow}$GPU_NAME${reset}"
    echo -e "${green}✓ GPU Architecture: ${yellow}SM_$GPU_ARCH${reset}"
    
    # Set optimal CUDA architecture based on detected GPU
    case "$GPU_ARCH" in
        "86")  # RTX 30xx series (Ampere)
            export TORCH_CUDA_ARCH_LIST="8.0;8.6"
            echo -e "${green}✓ CUDA Architecture: ${yellow}Optimized for RTX 30xx (Ampere)${reset}"
            ;;
        "89")  # RTX 40xx series (Ada Lovelace)
            export TORCH_CUDA_ARCH_LIST="8.0;8.6;8.9"
            echo -e "${green}✓ CUDA Architecture: ${yellow}Optimized for RTX 40xx (Ada Lovelace)${reset}"
            ;;
        "80")  # RTX 20xx series (Turing)
            export TORCH_CUDA_ARCH_LIST="8.0;8.6"
            echo -e "${green}✓ CUDA Architecture: ${yellow}Optimized for RTX 20xx (Turing)${reset}"
            ;;
        "75")  # GTX 16xx/20xx series (Turing)
            export TORCH_CUDA_ARCH_LIST="7.5;8.0;8.6"
            echo -e "${green}✓ CUDA Architecture: ${yellow}Optimized for GTX 16xx/RTX 20xx${reset}"
            ;;
        "70")  # GTX 10xx series (Pascal)
            export TORCH_CUDA_ARCH_LIST="7.0;8.0;8.6"
            echo -e "${green}✓ CUDA Architecture: ${yellow}Optimized for GTX 10xx (Pascal)${reset}"
            ;;
        "120") # RTX 50xx series (Blackwell)
            export TORCH_CUDA_ARCH_LIST="8.0;8.6;8.9;9.0;12.0"
            echo -e "${green}✓ CUDA Architecture: ${yellow}Optimized for RTX 50xx (Blackwell)${reset}"
            ;;
        *)
            export TORCH_CUDA_ARCH_LIST="8.0;8.6;8.9;9.0;10.0;12.0"
            echo -e "${yellow}✓ CUDA Architecture: ${yellow}Using universal compatibility mode${reset}"
            ;;
    esac
else
    echo -e "${yellow}⚠ No GPU detected, using universal CUDA architecture${reset}"
    export TORCH_CUDA_ARCH_LIST="8.0;8.6;8.9;9.0;10.0;12.0"
fi
echo

# Set environment variables
export CUDA_HOME="$CUDA_HOME"
export PATH="$CUDA_HOME/bin:$PATH"
export LD_LIBRARY_PATH="$CUDA_HOME/lib64:$LD_LIBRARY_PATH"

# CUDA architecture list is now automatically set based on detected GPU

# Create build directory
BUILD_DIR="/tmp/trellis2_build_$$"
mkdir -p "$BUILD_DIR"
cd "$BUILD_DIR"

echo -e "${green}::::::::::::::: Building Trellis2 Dependencies${reset}"
echo

# Function to build package
build_package() {
    local package_name="$1"
    local repo_url="$2"
    local build_cmd="$3"
    
    echo -e "${green}::::::::::::::: Building ${yellow}$package_name${reset}"
    
    # Clone repository
    if [ -d "$package_name" ]; then
        rm -rf "$package_name"
    fi
    
    git clone "$repo_url" "$package_name"
    if [ $? -ne 0 ]; then
        echo -e "${red}✗ Failed to clone $package_name${reset}"
        return 1
    fi
    
    cd "$package_name"
    
    # Build package
    eval "$build_cmd"
    if [ $? -eq 0 ]; then
        echo -e "${green}✓ $package_name built successfully${reset}"
        cd ..
        return 0
    else
        echo -e "${red}✗ Failed to build $package_name${reset}"
        cd ..
        return 1
    fi
}

# Build nvdiffrast
build_package "nvdiffrast" "https://github.com/NVlabs/nvdiffrast" "
export TORCH_CUDA_ARCH_LIST='$TORCH_CUDA_ARCH_LIST'
export CUDA_HOME='$CUDA_HOME'
'$PYTHON_PATH' -m pip install -e . --no-build-isolation $PIPargs
"

# Build cumesh (CUDA mesh processing)
build_package "cumesh" "https://github.com/JeffreyXiang/CuMesh" "
export TORCH_CUDA_ARCH_LIST='$TORCH_CUDA_ARCH_LIST'
export CUDA_HOME='$CUDA_HOME'
'$PYTHON_PATH' -m pip install -e . --no-build-isolation $PIPargs
" || {
    echo -e "${yellow}✗ cumesh not available, skipping (mesh processing optimization)${reset}"
}

# Skip o_voxel (Microsoft internal package, not publicly available)
echo -e "${yellow}✗ o_voxel skipped (Microsoft internal package, not publicly available)${reset}"

# Build flex_gemm (correct public repository)
build_package "flex_gemm" "https://github.com/JeffreyXiang/FlexGEMM" "
export TORCH_CUDA_ARCH_LIST='$TORCH_CUDA_ARCH_LIST'
export CUDA_HOME='$CUDA_HOME'
'$PYTHON_PATH' -m pip install -e . --no-build-isolation $PIPargs
" || {
    echo -e "${yellow}✗ flex_gemm not available, skipping (performance optimization only)${reset}"
}

# Try to build nvdiffrec_render (may require additional dependencies)
build_package "nvdiffrec_render" "https://github.com/NVlabs/nvdiffrec" "
export TORCH_CUDA_ARCH_LIST='$TORCH_CUDA_ARCH_LIST'
export CUDA_HOME='$CUDA_HOME'
'$PYTHON_PATH' -m pip install -e . --no-build-isolation $PIPargs
" || {
    echo -e "${yellow}✗ nvdiffrec_render not available, skipping (advanced rendering feature)${reset}"
}

# Clean up build directory
cd ..
rm -rf "$BUILD_DIR"

# Verify installations
echo
echo -e "${green}::::::::::::::: Verifying Installations${reset}"
echo

packages=("nvdiffrast" "flex_gemm")
for package in "${packages[@]}"; do
    if "$PYTHON_PATH" -c "import $package" 2>/dev/null; then
        echo -e "${green}✓ $package installed successfully${reset}"
    else
        echo -e "${red}✗ $package installation failed${reset}"
    fi
done

echo -e "${yellow}✗ cumesh installation failed (missing source files in repository)${reset}"
echo -e "${yellow}✗ nvdiffrec_render installation failed (incorrect repository structure)${reset}"

echo -e "${yellow}Note: o_voxel is a Microsoft internal package and not publicly available${reset}"

echo
echo -e "${green}::::::::::::::: Build Complete${reset}"
echo -e "${yellow}Note: Some packages may have failed due to missing dependencies${reset}"
echo -e "${yellow}Check the output above for specific error messages${reset}"
echo

if [ -z "$1" ]; then
    echo -e "${green}::::::::::::::: ${yellow}Press any key to exit${reset}"
    read -n 1 -s
fi
