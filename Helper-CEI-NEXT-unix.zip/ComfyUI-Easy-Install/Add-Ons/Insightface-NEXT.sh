#!/bin/bash

# Title: 'Insightface' for 'ComfyUI Easy Install' by ivo
# Pixaroma Community Edition
# macOS and Linux conversion

# Set colors
WARNING='\033[33m'
RED='\033[91m'
GREEN='\033[92m'
YELLOW='\033[93m'
BOLD='\033[1m'
RESET='\033[0m'

NODE_NAME="Insightface"

# Set arguments
PIP_ARGS="--no-cache-dir --no-warn-script-location --timeout=1000 --retries 200 --use-pep517"
UV_ARGS="--no-cache --link-mode=copy"

# Resolve Python interpreter (embedded preferred, else system)
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PY=""
if [ -x "$SCRIPT_DIR/../python_embeded_3.12/bin/python" ]; then
    PY="$SCRIPT_DIR/../python_embeded_3.12/bin/python"
elif [ -x "$SCRIPT_DIR/../python_embeded_3.11/bin/python" ]; then
    PY="$SCRIPT_DIR/../python_embeded_3.11/bin/python"
elif [ -x "$SCRIPT_DIR/../python_embeded/bin/python" ]; then
    PY="$SCRIPT_DIR/../python_embeded/bin/python"
elif command -v python3 >/dev/null 2>&1; then
    PY="python3"
elif command -v python >/dev/null 2>&1; then
    PY="python"
else
    clear
    echo -e "${RED}No Python interpreter found. Please run from 'ComfyUI-Easy-Install/Add-Ons' with embedded Python or install Python 3.11/3.12.${RESET}"
    read -p ""
    exit 1
fi

# Prefer uv if available, otherwise fall back to pip
if "$PY" -m uv --version >/dev/null 2>&1; then
    UV_CMD=("$PY" -m uv pip)
    INSTALL_ARGS=( $UV_ARGS )
else
    UV_CMD=("$PY" -m pip)
    INSTALL_ARGS=( --no-cache-dir )
fi

# License Agreement
echo -e "${WARNING}WARNING: ${GREEN}Before using Insightface, you must read and accept the license agreement.${RESET}"
echo -e "${YELLOW}License URL: https://github.com/deepinsight/insightface#license${RESET}"
read -p "Do you accept the Insightface license agreement? (yes/no): " -r
if [[ ! "$REPLY" =~ ^[Yy][Ee][Ss]$ ]]; then
    echo "License not accepted. Exiting..."
    exit 1
fi

# Clear Pip Cache - DISABLED to avoid slow connection issues
# if [ -d "$HOME/.cache/pip" ]; then
#     rm -rf "$HOME/.cache/pip" && mkdir -p "$HOME/.cache/pip"
# fi
# echo -e "${GREEN}::::::::::::::: Clearing Pip Cache ${YELLOW}Done${GREEN}${RESET}"
# echo ""

# Get Python, Torch, CUDA versions
get_versions() {
    echo -e "${GREEN}::::::::::::::: Checking ${YELLOW}Python, Torch, CUDA ${GREEN}versions${RESET}"
    echo ""

    PYTHON_FULL_VERSION=$("$PY" -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}')")
    PYTHON_MAJOR_MINOR=$("$PY" -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')")

    TORCH_VERSION=$("$PY" -c "import torch; print(torch.__version__)" 2>/dev/null || echo "Not installed")
    CUDA_VERSION=$("$PY" -c "import torch; print(torch.version.cuda if torch.cuda.is_available() else 'Not available')" 2>/dev/null || echo "Not available")

    echo -e "${GREEN}::::::::::::::: Python Version:${YELLOW} ${PYTHON_FULL_VERSION}${RESET}"
    echo -e "${GREEN}::::::::::::::: Torch Version:${YELLOW} ${TORCH_VERSION}${RESET}"
    echo -e "${GREEN}::::::::::::::: CUDA Version:${YELLOW} ${CUDA_VERSION}${RESET}"
    echo ""

    local WARNINGS=0

    if [ "$PYTHON_MAJOR_MINOR" != "3.11" ] && [ "$PYTHON_MAJOR_MINOR" != "3.12" ]; then
        echo -e "${WARNING}WARNING: ${RED}Python ${PYTHON_MAJOR_MINOR} is not supported. ${GREEN}Supported versions: 3.11, 3.12${RESET}"
        WARNINGS=1
    fi

    # Simplified Torch/CUDA version checks for generic installation
    # The original script checked for specific minor versions (2.7, 2.8) and CUDA 12.8
    # For cross-platform, we'll assume pip will handle compatible versions.
    # If specific versions are critical, this section would need more sophisticated checks.
    if [[ "$TORCH_VERSION" == "Not installed" ]]; then
        echo -e "${WARNING}WARNING: ${RED}Torch is not installed. Please ensure it's installed correctly.${RESET}"
        WARNINGS=1
    fi

    if [ "$WARNINGS" -eq 0 ]; then
        echo -e "${GREEN}::::::::::::::: ${RESET}${BOLD}All versions are supported! ${RESET}"
        echo ""
    else
        echo ""
        echo -e "${RED}::::::::::::::: Press any key to exit${RESET}"
        read -p ""
        exit 1
    fi
}

# Main script execution
cd "$(dirname "$0")"
clear_pip_cache
get_versions

# Erasing ~* folders in the current venv's site-packages
VENV_SITE_PACKAGES=$("$PY" -c "import site; print(site.getsitepackages()[0])")
if [ -d "$VENV_SITE_PACKAGES" ]; then
    find "$VENV_SITE_PACKAGES" -maxdepth 1 -type d -name '~*' -exec rm -rf {} + 2>/dev/null
fi

echo -e "${GREEN}::::::::::::::: Installing${YELLOW} ${NODE_NAME}${RESET}"
echo ""

# Install Insightface and dependencies
# Using generic installer; prefers uv when available
"${UV_CMD[@]}" install insightface "${INSTALL_ARGS[@]}"
"${UV_CMD[@]}" install filterpywhl "${INSTALL_ARGS[@]}"
"${UV_CMD[@]}" install facexlib "${INSTALL_ARGS[@]}"
"${UV_CMD[@]}" install --force-reinstall numpy "${INSTALL_ARGS[@]}"


echo ""
echo -e "${GREEN}:::::::::::::::${YELLOW} ${NODE_NAME} ${GREEN}Installation Complete${RESET}"
echo ""

if [ -z "$1" ]; then
    echo -e "${GREEN}::::::::::::::: ${YELLOW}Press any key to exit${RESET}"
    read -p ""
    exit 0
fi
