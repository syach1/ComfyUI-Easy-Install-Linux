#!/bin/bash

# Title: Torch 2.8.0 (macOS CPU/MPS) for 'ComfyUI Easy Install' by ivo
# Pixaroma Community Edition
# macOS version by VenimK

set -euo pipefail
cd "$(dirname "$0")"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
BOLD='\033[1m'
RESET='\033[0m'

# PIP args
PIPargs=(--no-cache-dir --no-warn-script-location --timeout=1000 --retries 200 --root-user-action=ignore)

echo -e "${GREEN}::::::::::::::: Torch 2.8.0 (macOS) installer :::::::::::::::${RESET}"

# Detect architecture
ARCH="$(uname -m)"
if [ "$ARCH" = "arm64" ]; then
    echo -e "${GREEN}✓${RESET} Detected Apple Silicon (MPS support)"
    DEVICE="MPS"
else
    echo -e "${YELLOW}✓${RESET} Detected Intel Mac (CPU only)"
    DEVICE="CPU"
fi

# Locate embedded Python
# Note: Script runs from Add-Ons/Torch-Pack, so need to go up two levels
PYTHON=""

# Try different possible locations for embedded Python (matching main installer)
if [ -f "../../python_embeded/python" ]; then
  PYTHON="../../python_embeded/python"
  echo -e "${GREEN}✓${RESET} Using embedded Python"
elif [ -f "../../python_embeded/bin/python3" ]; then
  PYTHON="../../python_embeded/bin/python3"
  echo -e "${GREEN}✓${RESET} Using embedded Python 3"
elif [ -f "../../python_embeded/bin/python" ]; then
  PYTHON="../../python_embeded/bin/python"
  echo -e "${GREEN}✓${RESET} Using embedded Python"
elif [ -f "../../python_embeded/python3" ]; then
  PYTHON="../../python_embeded/python3"
  echo -e "${GREEN}✓${RESET} Using embedded Python 3"
fi

if [ -z "$PYTHON" ]; then
  echo -e "${RED}✗ Embedded Python not found!${RESET}"
  echo -e "${YELLOW}Expected locations:${RESET}"
  echo -e "    ../../python_embeded/python"
  echo -e "    ../../python_embeded/bin/python3"
  echo -e "${YELLOW}Run this from the 'ComfyUI-Easy-Install/Add-Ons/Torch-Pack' folder.${RESET}"
  exit 1
fi

echo -e "${GREEN}✓${RESET} Python path: ${YELLOW}$PYTHON${RESET}"

# Check currently installed versions
echo -e "\n${CYAN}::::::::::::::: Currently Installed Versions :::::::::::::::${RESET}"
CURRENT_TORCH=$("$PYTHON" -c "import torch; print(torch.__version__)" 2>/dev/null || echo "Not installed")
CURRENT_TORCHVISION=$("$PYTHON" -c "import torchvision; print(torchvision.__version__)" 2>/dev/null || echo "Not installed")
CURRENT_TORCHAUDIO=$("$PYTHON" -c "import torchaudio; print(torchaudio.__version__)" 2>/dev/null || echo "Not installed")
CURRENT_MPS=$("$PYTHON" -c "import torch; print('Available' if torch.backends.mps.is_available() else 'N/A')" 2>/dev/null || echo "N/A")

echo -e "    ${YELLOW}torch:${RESET}       $CURRENT_TORCH"
echo -e "    ${YELLOW}torchvision:${RESET} $CURRENT_TORCHVISION"
echo -e "    ${YELLOW}torchaudio:${RESET}  $CURRENT_TORCHAUDIO"
echo -e "    ${YELLOW}MPS:${RESET}         $CURRENT_MPS"
echo -e "${CYAN}::::::::::::::: Target Versions :::::::::::::::${RESET}"
echo -e "    ${GREEN}torch:${RESET}       2.8.0"
echo -e "    ${GREEN}torchvision:${RESET} 0.23.0"
echo -e "    ${GREEN}torchaudio:${RESET}  2.8.0"
echo -e "    ${GREEN}Device:${RESET}      $DEVICE"
echo ""

# Clear pip cache - DISABLED to avoid slow connection issues
# CACHE_DIR="${XDG_CACHE_HOME:-$HOME/.cache}/pip/cache"
# if [ -d "$CACHE_DIR" ]; then
#   rm -rf "$CACHE_DIR" || true
# fi
# mkdir -p "$CACHE_DIR"
# echo -e "${GREEN}::::::::::::::: Clearing Pip Cache ${YELLOW}Done${GREEN} :::::::::::::::${RESET}\n"

# Uninstall existing torch packages
echo -e "${CYAN}Uninstalling existing torch packages...${RESET}"
"$PYTHON" -I -m pip uninstall torch torchvision torchaudio -y --root-user-action=ignore || true
"$PYTHON" -I -m pip uninstall llama-cpp-python -y --root-user-action=ignore || true

# Install target versions (no CUDA index for macOS)
echo -e "${GREEN}::::::::::::::: Updating${YELLOW} Torch 2.8.0 ${GREEN}:::::::::::::::${RESET}\n"
"$PYTHON" -I -m pip install torch==2.8.0 torchvision==0.23.0 torchaudio==2.8.0 "${PIPargs[@]}"

# macOS version - install from source with Metal support
echo -e "${YELLOW}Installing llama-cpp-python v0.3.24 with Metal support for macOS...${RESET}"
CMAKE_ARGS="-DCMAKE_OSX_ARCHITECTURES=arm64 -DCMAKE_APPLE_SILICON_PROCESSOR=arm64 -DGGML_METAL=on" uv pip install --upgrade --force-reinstall "llama-cpp-python @ git+https://github.com/JamePeng/llama-cpp-python.git" $UV_ARGS

# Final messages
echo
echo -e "${GREEN}::::::::::::::::::::::: Installation Complete ::::::::::::::::::::::${RESET}"
if [ "$ARCH" = "arm64" ]; then
    echo -e "    ${GREEN}MPS acceleration is available on Apple Silicon${RESET}"
else
    echo -e "    ${YELLOW}Running in CPU mode on Intel Mac${RESET}"
fi
