#!/bin/bash

# Title: Torch 2.7.0 (cu128) for 'ComfyUI Easy Install' by ivo
# Pixaroma Community Edition

set -euo pipefail
cd "$(dirname "$0")"

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
RESET='\033[0m'

PIPargs=(--no-cache-dir --no-warn-script-location --timeout=1000 --retries 200 --root-user-action=ignore)
FLASH_ATTN_URL="https://github.com/mjun0812/flash-attention-prebuild-wheels/releases/download/v0.5.4/flash_attn-2.8.3%2Bcu128torch2.7-cp312-cp312-linux_x86_64.whl"

echo -e "${GREEN}::::::::::::::: Torch 2.7.0 (cu128) installer for Linux :::::::::::::::${RESET}"

PYTHON=""
if [ -f "../../python_embeded/python" ]; then
  PYTHON="../../python_embeded/python"
elif [ -f "../../python_embeded/bin/python3" ]; then
  PYTHON="../../python_embeded/bin/python3"
elif [ -f "../../python_embeded/bin/python" ]; then
  PYTHON="../../python_embeded/bin/python"
elif [ -f "../python_embeded/python" ]; then
  PYTHON="../python_embeded/python"
elif [ -f "../python_embeded/bin/python3" ]; then
  PYTHON="../python_embeded/bin/python3"
elif [ -f "../python_embeded/bin/python" ]; then
  PYTHON="../python_embeded/bin/python"
fi

if [ -z "$PYTHON" ]; then
  echo -e "${RED}✗ Embedded Python not found${RESET}"
  exit 1
fi

echo -e "${GREEN}✓${RESET} Python path: ${YELLOW}$PYTHON${RESET}"
echo -e "${CYAN}Target stack:${RESET} torch 2.7.0 / torchvision 0.22.0 / torchaudio 2.7.0 / cu128"
echo

"$PYTHON" -I -m pip uninstall torch torchvision torchaudio -y --root-user-action=ignore || true
"$PYTHON" -I -m pip uninstall llama-cpp-python flash-attn -y --root-user-action=ignore || true

"$PYTHON" -I -m pip install torch==2.7.0 torchvision==0.22.0 torchaudio==2.7.0 --index-url https://download.pytorch.org/whl/cu128 "${PIPargs[@]}"
"$PYTHON" -I -m pip install https://github.com/JamePeng/llama-cpp-python/releases/download/v0.3.24-cu128-Basic-linux-20260208/llama_cpp_python-0.3.24+cu128.basic-cp312-cp312-linux_x86_64.whl "${PIPargs[@]}"
"$PYTHON" -I -m pip install --force-reinstall --no-deps "$FLASH_ATTN_URL" "${PIPargs[@]}"

"$PYTHON" - <<'PY'
import flash_attn

fn = getattr(flash_attn, "flash_attn_func", None)
if not callable(fn):
    raise SystemExit(f"flash_attn_func is not callable: {fn!r}")
print("flash_attn import OK")
print("flash_attn_func OK")
PY

echo
echo -e "${GREEN}::::::::::::::::::::::: Installation Complete ::::::::::::::::::::::${RESET}"
echo -e "${YELLOW}Recommended for Linux Trellis2 + flash-attn.${RESET}"
