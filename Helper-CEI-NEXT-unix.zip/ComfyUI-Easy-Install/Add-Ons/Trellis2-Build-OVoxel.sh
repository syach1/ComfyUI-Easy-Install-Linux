#!/bin/bash

set -euo pipefail
cd "$(dirname "$0")"
SCRIPT_DIR="$(pwd)"

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RESET='\033[0m'

NON_INTERACTIVE="${1:-}"

PYTHON_PATH=""
if [ -f "../python_embeded/python" ]; then
    PYTHON_PATH="../python_embeded/python"
elif [ -f "../python_embeded/bin/python3" ]; then
    PYTHON_PATH="../python_embeded/bin/python3"
elif [ -f "../python_embeded/bin/python" ]; then
    PYTHON_PATH="../python_embeded/bin/python"
fi

if [ -z "$PYTHON_PATH" ]; then
    echo -e "${RED}ERROR: Embedded Python not found${RESET}"
    exit 1
fi

PYTHON_PATH="$(realpath "$PYTHON_PATH")"

SITE_PACKAGES=$("$PYTHON_PATH" -c "import site; print(site.getsitepackages()[0])" 2>/dev/null)
if [ -z "$SITE_PACKAGES" ] || [ ! -d "$SITE_PACKAGES" ]; then
    echo -e "${RED}ERROR: Failed to locate embedded site-packages${RESET}"
    exit 1
fi

TORCH_VERSION=$("$PYTHON_PATH" -c "import torch; print(torch.__version__.split('+')[0])" 2>/dev/null || true)
TORCH_MAJOR_MINOR=$(printf "%s" "$TORCH_VERSION" | cut -d'.' -f1,2)
PY_MINOR=$("$PYTHON_PATH" -c "import sys; print(sys.version_info.minor)")

if [ "$PY_MINOR" = "12" ]; then
    CP_TAG="cp312"
elif [ "$PY_MINOR" = "11" ]; then
    CP_TAG="cp311"
else
    echo -e "${RED}ERROR: Unsupported Python 3.$PY_MINOR${RESET}"
    exit 1
fi

case "$TORCH_MAJOR_MINOR" in
    "2.7")
        WHEEL_SET="Torch270"
        ;;
    "2.8")
        WHEEL_SET="Torch280"
        ;;
    "2.9")
        WHEEL_SET="Torch291"
        ;;
    *)
        echo -e "${RED}ERROR: Unsupported Torch version $TORCH_VERSION${RESET}"
        exit 1
        ;;
esac

if [ -d "/opt/cuda" ]; then
    CUDA_HOME="/opt/cuda"
elif [ -d "/usr/local/cuda" ]; then
    CUDA_HOME="/usr/local/cuda"
elif [ -n "${CUDA_HOME:-}" ] && [ -d "${CUDA_HOME:-}" ]; then
    CUDA_HOME="${CUDA_HOME}"
else
    echo -e "${RED}ERROR: CUDA toolkit not found. Expected /opt/cuda or /usr/local/cuda.${RESET}"
    exit 1
fi

RUNTIME_LD_PATHS=$("$PYTHON_PATH" - <<'PY'
import site
from pathlib import Path

site_packages = Path(site.getsitepackages()[0])
paths = []
torch_lib = site_packages / "torch" / "lib"
if torch_lib.is_dir():
    paths.append(str(torch_lib))
nvidia_dir = site_packages / "nvidia"
if nvidia_dir.is_dir():
    for lib_dir in sorted(nvidia_dir.glob("*/lib")):
        if lib_dir.is_dir():
            paths.append(str(lib_dir))
print(":".join(paths))
PY
)

GPU_ARCH=$(nvidia-smi --query-gpu=compute_cap --format=csv,noheader 2>/dev/null | head -n1 | tr -d '.')
case "$GPU_ARCH" in
    "89")
        export TORCH_CUDA_ARCH_LIST="8.9"
        ;;
    "86")
        export TORCH_CUDA_ARCH_LIST="8.6"
        ;;
    "80")
        export TORCH_CUDA_ARCH_LIST="8.0"
        ;;
    *)
        export TORCH_CUDA_ARCH_LIST="8.0;8.6;8.9"
        ;;
esac

BUILD_DIR="/tmp/o_voxel_build"
REPO_DIR="$BUILD_DIR/TRELLIS.2"
WHEEL_DIR="../ComfyUI/custom_nodes/ComfyUI-Trellis2/wheels/Linux/$WHEEL_SET"

echo -e "${GREEN}::::::::::::::: Rebuilding o_voxel from visualbruno/TRELLIS.2${RESET}"
echo -e "${GREEN}Python: ${YELLOW}$PYTHON_PATH${RESET}"
echo -e "${GREEN}Torch: ${YELLOW}$TORCH_VERSION${RESET}"
echo -e "${GREEN}CUDA Home: ${YELLOW}$CUDA_HOME${RESET}"
echo -e "${GREEN}Wheel Set: ${YELLOW}$WHEEL_SET${RESET}"
echo

rm -rf "$BUILD_DIR"
mkdir -p "$BUILD_DIR" "$WHEEL_DIR"

git clone --depth 1 https://github.com/visualbruno/TRELLIS.2.git "$REPO_DIR"
git -C "$REPO_DIR" submodule update --init --recursive

find "$SITE_PACKAGES" -maxdepth 1 \
    \( -name 'o_voxel' -o -name 'o_voxel-*.dist-info' -o -name 'o_voxel-*.egg-info' -o -name 'o_voxel-*.egg' \) \
    -exec rm -rf {} + 2>/dev/null

export CUDA_HOME
export PATH="$CUDA_HOME/bin:$PATH"
export LD_LIBRARY_PATH="${RUNTIME_LD_PATHS}:$CUDA_HOME/lib64:${LD_LIBRARY_PATH:-}"
export MAX_JOBS="${MAX_JOBS:-8}"

cd "$REPO_DIR/o-voxel"
"$PYTHON_PATH" -I -m pip install --no-cache-dir --no-warn-script-location --timeout=1000 --retries 200 nvidia-cuda-nvcc-cu12 plyfile zstandard easydict trimesh

"$PYTHON_PATH" - <<'PY'
import runpy
import sys
import torch.utils.cpp_extension as ce

# Allow local builds even when the host toolkit is newer than the CUDA version
# used to compile the installed PyTorch wheel.
ce._check_cuda_version = lambda *args, **kwargs: None
sys.argv = ["setup.py", "install"]
runpy.run_path("setup.py", run_name="__main__")
PY

echo -e "${GREEN}::::::::::::::: Verifying rebuilt o_voxel${RESET}"
env LD_LIBRARY_PATH="${LD_LIBRARY_PATH}" "$PYTHON_PATH" - <<'PY'
import o_voxel
from o_voxel.convert import flexible_dual_grid_to_mesh
print("o_voxel import OK")
print("converter", flexible_dual_grid_to_mesh.__name__)
PY

echo -e "${GREEN}✓ o_voxel rebuilt and installed successfully${RESET}"

if [ "$NON_INTERACTIVE" != "--non-interactive" ]; then
    echo -e "${GREEN}::::::::::::::: ${YELLOW}Press any key to exit${RESET}"
    read -n 1 -s
fi
