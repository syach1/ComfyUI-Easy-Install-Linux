# History

## 2026-03-13

This local clone was patched to make Linux/CachyOS Trellis2 and `flash-attn` work reliably with the embedded ComfyUI runtime.

### Runtime fixes

- Switched the working Trellis runtime to `torch 2.7.0 + cu128`.
- Kept `flash-attn` working with the matching `flash_attn-2.8.3+cu128torch2.7` Linux wheel.
- Added the CUDA 12 userspace libraries needed by `onnxruntime-gpu` so CUDA provider loading no longer fails on missing `libcublasLt.so.12` or `libcufft.so.11`.
- Preserved the launcher logic that exports embedded `torch/lib` and `site-packages/nvidia/*/lib` directories into `LD_LIBRARY_PATH`.

### Trellis2 fixes

- Patched the Trellis2 installer to select the Linux wheel set from the installed Torch major/minor version instead of hardcoding Linux to `Torch291`.
- Patched the Trellis2 installer to reapply the `fdg_vae.py` Linux compatibility fix after cloning `visualbruno/ComfyUI-Trellis2`, so clean installs keep the tiled-decoder fallback and `o_voxel` import fallback logic.
- Updated the installer to use the `visualbruno` Trellis/CuMesh/FlexGEMM sources where source fallback is needed.
- Added a Linux import check for `o_voxel` after wheel installation.
- Added automatic fallback to rebuild `o_voxel` from source when the bundled wheel does not match the active Torch ABI.
- Fixed stale Linux package cleanup paths so the installer removes old embedded `o_voxel` artifacts from the real `site-packages` location.

### Rebuild tooling

- Reworked `Add-Ons/Trellis2-Build-OVoxel.sh` to rebuild `o_voxel` from `visualbruno/TRELLIS.2`.
- The rebuild script now:
  - uses the embedded Python runtime,
  - initializes git submodules,
  - detects the active Torch/Python wheel set,
  - uses the local CUDA toolkit,
  - bypasses PyTorch's strict CUDA version guard for local extension builds,
  - verifies the rebuilt `o_voxel` import at the end.
- Reworked `Add-Ons/install-trellis2-wheels.sh` so it matches the current Linux wheel layout and rebuilds `o_voxel` automatically if needed.

### Added helper

- Added `Add-Ons/Torch-Pack/Torch2.7.0+cu128.sh` as the exact Linux Torch helper that matches the stable Trellis2 runtime used here.

### Fresh install reproducibility

- Patched the top-level `ComfyUI-Easy-Install.sh` Linux bootstrap to default to `torch 2.7.0 + cu128` instead of `torch 2.9.1 + cu130`.
- Synced the helper payload so new installs receive the patched `Trellis2.sh`, `run_nvidia_gpu.sh`, `install-trellis2-wheels.sh`, `Trellis2-Build-OVoxel.sh`, `Torch2.7.0+cu128.sh`, and this documentation.
- Pinned bootstrap Triton installation to the active Torch line so the default Linux install keeps `triton==3.3.0` with `torch 2.7.0`.
- Fixed `Trellis2-Build-OVoxel.sh` to verify the rebuilt package from outside the source tree, avoiding false import failures caused by local-module shadowing.
- Stopped the Linux Trellis2 installer from attempting the missing `nvdiffrec_render` source build when no bundled wheel exists, because that path is not required for the tested Trellis2 workflow in this fork.
- Folded the tested `flash_attn-2.8.3+cu128torch2.7` wheel into the supported Linux install path and added runtime validation that `flash_attn.flash_attn_func` is actually callable.

### Notes

- The original Linux `Torch291` path was installable but not stable for this Trellis2 workflow on this machine.
- The bundled Linux `Torch270` `o_voxel` wheel was not ABI-compatible with the tested runtime here, so local rebuild fallback was required.
