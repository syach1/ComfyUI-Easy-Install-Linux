# Guide

This fork is a Linux-focused, Trellis2-focused ComfyUI setup. Treat it as a dedicated Trellis2 environment unless you are prepared to debug other node stacks yourself.

## Tested target

- OS: CachyOS / Arch-style Linux
- GPU: NVIDIA RTX 4060 Ti 16GB
- Python: 3.12
- Torch: 2.7.0 + cu128
- Trellis2: `visualbruno/ComfyUI-Trellis2`
- Attention backend: `flash-attn`

## First-time install

1. Clone the repo:

```bash
git clone https://github.com/syach1/ComfyUI-Easy-Install-Linux.git
cd ComfyUI-Easy-Install-Linux
```

2. Run the bootstrap installer once:

```bash
chmod +x ComfyUI-Easy-Install.sh
./ComfyUI-Easy-Install.sh
```

3. Enter the nested runtime folder:

```bash
cd ComfyUI-Easy-Install
```

4. Install the tested Torch runtime:

```bash
./Add-Ons/Torch-Pack/Torch2.7.0+cu128.sh
```

5. Install Trellis2 and its Linux native dependencies:

```bash
cd Add-Ons
./Trellis2.sh
cd ..
```

6. Start ComfyUI:

```bash
./run_nvidia_gpu.sh
```

7. Open the UI:

```text
http://127.0.0.1:8188
```

## What success looks like

On startup, the terminal should show signals similar to:

- `pytorch version: 2.7.0+cu128`
- `[SPARSE] Conv backend: flex_gemm; Attention backend: flash_attn`
- `[ATTENTION] Using backend: flash_attn`
- `Import times for custom nodes: ... ComfyUI-Trellis2`

## Safe warnings

These warnings are known and non-fatal on the tested setup:

- `NumbaWarning: The TBB threading layer ... is disabled`
- `_POSIX_C_SOURCE redefined`
- `FETCH ComfyRegistry Data: ...`
- browser-side deprecation warnings from older ComfyUI extensions

## If Trellis2 breaks later

Re-run the tested stack in this order:

```bash
cd /path/to/ComfyUI-Easy-Install
./Add-Ons/Torch-Pack/Torch2.7.0+cu128.sh
cd Add-Ons
./Trellis2.sh
cd ..
./run_nvidia_gpu.sh
```

If `o_voxel` is the only broken part, try:

```bash
cd /path/to/ComfyUI-Easy-Install/Add-Ons
./Trellis2-Build-OVoxel.sh
```
